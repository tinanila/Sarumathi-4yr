import { Component, OnInit } from '@angular/core';
import { Chart, registerables } from 'chart.js';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.css']
})
export class BarChartComponent implements OnInit {

  constructor() { }
  public barChartOptions:any = {
    scaleShowVerticalLines: false,
    responsive: true,
    barThickness: 20
  };

    public mbarChartLabels:string[] = ['Assignment', 'Quiz', 'Presentaiton', 'Lab', 'Viva'];
    public barChartType:string = 'bar';
    public barChartLegend:boolean = true;
  
    public barChartData:any[] = [
      {data: [29,36,80,32, 67], label: 'Completed',  borderColor: 'green',
      backgroundColor: 'green'},
      {data: [100,32,43,45,22], label: 'Pending', borderColor: 'grey',
      backgroundColor: 'green'},
      {data: [100,32,43,45,22], label: 'Pending', borderColor: 'grey',
      backgroundColor: 'grey'}
    ];
  
 ngOnInit(): void {

 }

}
