import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-details',
  templateUrl: './course-details.component.html',
  styleUrls: ['./course-details.component.css']
})
export class CourseDetailsComponent implements OnInit {

  courseDetails = {
    courseCode: 'BA3102',
    courseName: 'Quantitative Techniques',
    courseType: 'Program Electives',
    coursePeriod: 'Semester 1',
    credits: [{'description': 'Lecture' , 'point': 3},{'description': 'Tutorial', 'point': 0}, {'description': 'Practical', 'point': 1},{'description': 'Projects' , 'point': 0}],
    courseOutcomes: ['CO2', 'CO4', 'CO5', 'CO7', 'CO13', 'CO14'],
    msppedCourse: ['PO7', 'PO10', 'PO12', 'PO8']  
  };
  constructor() { }

  ngOnInit(): void {
  }

}
